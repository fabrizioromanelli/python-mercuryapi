using System;
using System.Collections.Generic;
using System.Text;
using ThingMagic;

namespace MercuryAPIHello
{
    class Program
    {
        static void Main(string[] args)
        {
            Reader rdr = Reader.Create("tmr:///COM1", Region.NA);
            foreach (TagReadData dat in rdr.Read(1000))
            {
                Console.WriteLine(dat.ToString());
            }
        }
    }
}

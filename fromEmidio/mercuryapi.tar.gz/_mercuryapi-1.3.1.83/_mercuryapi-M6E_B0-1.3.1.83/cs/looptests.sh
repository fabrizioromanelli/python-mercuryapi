#!/bin/sh

while [ 1 ]; do
./runtests.sh
done
